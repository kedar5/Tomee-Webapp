package ds;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.PrintWriter;
import java.io.IOException;


@WebServlet(name = "ComputeHashes", value = "/ComputeHashes")
public class ComputeHashes extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String enteredValue = request.getParameter("entry");
        String hashingType = request.getParameter("hashing_type");
        PrintWriter out = response.getWriter();
        MessageDigest md;
        if (enteredValue != null) {
            try {
                // Access MessageDigest class for SHA-265
                if (hashingType == "SHA-256") {
                    md = MessageDigest.getInstance("SHA-256");
                } else {
                    md = MessageDigest.getInstance("MD5");
                }

                md.update(enteredValue.getBytes());
                byte[] hash = md.digest();

                out.println("<html><body>");
                out.println("<h2> Hash Result : </h2><br><h3> Entered Value :" + enteredValue + "</h3><h3> Hashing type: " + hashingType + "</h3>");
                out.println("<h3>Hash Value(base64):</h3>" + jakarta.xml.bind.DatatypeConverter.printBase64Binary(hash) + "<br>");
                out.println("<h3>Hash Value(hexadecimal): </h3>" + jakarta.xml.bind.DatatypeConverter.printHexBinary(hash) + "<br>");
                out.println("</body></html>");
            } catch (NoSuchAlgorithmException e) {
                System.out.println("No SHA-256 available" + e);
            }
        }


    }
}
